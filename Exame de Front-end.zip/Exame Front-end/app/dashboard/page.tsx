import { redirect } from 'next/navigation'
import { cookies } from 'next/headers'
import DashboardClient from './DashboardClient'

export default async function DashboardPage() {
  const armazenamentoCookies = await cookies()
  const estaAutenticado = armazenamentoCookies.get('isAuthenticated')?.value === 'true'

  if (!estaAutenticado) {
    redirect('/login')
  }

  return <DashboardClient />
}

