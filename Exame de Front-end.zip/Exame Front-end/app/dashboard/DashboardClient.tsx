'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card } from '@/types/card'
import './dashboard.css'

const ROTULOS_NAIPES: Record<string, string> = {
  HEARTS: 'Copas',
  DIAMONDS: 'Ouros',
  CLUBS: 'Paus',
  SPADES: 'Espadas',
}

const NAIPES = ['HEARTS', 'DIAMONDS', 'CLUBS', 'SPADES']

export default function DashboardClient() {
  const [cartas, setCartas] = useState<Card[]>([])
  const [cartasVisiveis, setCartasVisiveis] = useState<Card[]>([])
  const [naipeSelecionado, setNaipeSelecionado] = useState('ALL')
  const [carregando, setCarregando] = useState(true)
  const navegador = useRouter()

  useEffect(() => {
    carregarCartas()
  }, [])

  useEffect(() => {
    if (naipeSelecionado === 'ALL') {
      setCartasVisiveis(cartas)
    } else {
      setCartasVisiveis(cartas.filter((carta) => carta.suit === naipeSelecionado))
    }
  }, [naipeSelecionado, cartas])

  const carregarCartas = async () => {
    try {
      const cartasSalvas = localStorage.getItem('deckCards')
      if (cartasSalvas) {
        const cartasParseadas = JSON.parse(cartasSalvas)
        setCartas(cartasParseadas)
        setCartasVisiveis(cartasParseadas)
        setCarregando(false)
        return
      }

      const resposta = await fetch(
        'https://deckofcardsapi.com/api/deck/new/draw/?count=52'
      )
      const dados = await resposta.json()

      if (dados.success && dados.cards) {
        setCartas(dados.cards)
        setCartasVisiveis(dados.cards)
        localStorage.setItem('deckCards', JSON.stringify(dados.cards))
      }
    } catch (erro) {
      console.error('Erro ao carregar cartas:', erro)
    } finally {
      setCarregando(false)
    }
  }

  const embaralharCartas = () => {
    const embaralhadas = [...cartas].sort(() => Math.random() - 0.5)
    setCartas(embaralhadas)
    localStorage.setItem('deckCards', JSON.stringify(embaralhadas))
  }

  const lidarComLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      localStorage.removeItem('deckCards')
      navegador.push('/login')
    } catch (erro) {
      console.error('Erro ao fazer logout:', erro)
    }
  }

  if (carregando) {
    return (
      <div className="dashboard-container">
        <div className="loading">Carregando cartas...</div>
      </div>
    )
  }

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <h1>Baralho de Cartas</h1>
        <div className="header-actions">
          <button onClick={embaralharCartas} className="shuffle-button">
            Embaralhar
          </button>
          <button onClick={lidarComLogout} className="logout-button">
            Sair
          </button>
        </div>
      </header>

      <div className="filter-section">
        <label htmlFor="suit-filter">Filtrar por naipe:</label>
        <select
          id="suit-filter"
          value={naipeSelecionado}
          onChange={(e) => setNaipeSelecionado(e.target.value)}
          className="suit-filter"
        >
          <option value="ALL">Todos</option>
          {NAIPES.map((naipe) => (
            <option key={naipe} value={naipe}>
              {ROTULOS_NAIPES[naipe]}
            </option>
          ))}
        </select>
      </div>

      <div className="cards-grid">
        {cartasVisiveis.map((carta, indice) => (
          <div key={carta.code + indice} className="card-item">
            <img src={carta.image} alt={`${carta.value} de ${ROTULOS_NAIPES[carta.suit]}`} />
            <div className="card-info">
              <span className="card-value">{carta.value}</span>
              <span className="card-suit">{ROTULOS_NAIPES[carta.suit]}</span>
            </div>
          </div>
        ))}
      </div>

      <footer className="dashboard-footer">
        <p>Nome Completo: [Seu Nome Completo]</p>
        <p>RA: [Seu RA]</p>
      </footer>
    </div>
  )
}

