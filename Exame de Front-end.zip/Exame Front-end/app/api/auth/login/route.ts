import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'

export async function POST(requisicao: NextRequest) {
  try {
    const corpo = await requisicao.json()
    const { username, password } = corpo

    const senhaCorreta = process.env.AUTH_PASSWORD

    if (!senhaCorreta) {
      return NextResponse.json(
        { success: false, message: 'Erro de configuração' },
        { status: 500 }
      )
    }

    if (!username || !password) {
      return NextResponse.json(
        { success: false, message: 'Preencha todos os campos' },
        { status: 400 }
      )
    }

    if (password !== senhaCorreta) {
      return NextResponse.json(
        { success: false, message: 'Senha incorreta' },
        { status: 401 }
      )
    }

    const armazenamentoCookies = await cookies()
    armazenamentoCookies.set('isAuthenticated', 'true', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7
    })

    return NextResponse.json({ success: true })
  } catch (erro) {
    return NextResponse.json(
      { success: false, message: 'Erro no servidor' },
      { status: 500 }
    )
  }
}

