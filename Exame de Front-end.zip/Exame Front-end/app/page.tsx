import { redirect } from 'next/navigation'
import { cookies } from 'next/headers'

export default async function Home() {
  const armazenamentoCookies = await cookies()
  const estaAutenticado = armazenamentoCookies.get('isAuthenticated')?.value === 'true'

  if (!estaAutenticado) {
    redirect('/login')
  }

  redirect('/dashboard')
}

